/***********************************************************************//**
* @file			CardPile.java
* @author		Kurt E. Clothier
* @date			November 8, 2015
*
* @breif		A single pile of cards in a game
*
* @pre			Compiler: Eclipse - Mars Release (4.5.0)
* @pre			Java: JRE 7 or greater
*
* @see			http://www.projectsbykec.com/
* @see			PlayingCard
*
* @copyright	The MIT License (MIT) - see LICENSE.txt
****************************************************************************/

package games.engine.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/************************************************************************
 * The CardPile Class
 * - An individual pile of Playing Cards used in a game
 * - Basic attributes are immutable, Playing Cards in pile may change
 * - Cards are Last In - First Out
 * TODO
 * - Finish sorting methods (and testing)
 * - Integration testing with Board text file
 ************************************************************************/
public class CardPile {
	
/*------------------------------------------------
 	Keyword Parameter Enumerations
 ------------------------------------------------*/
	
	/**
	 * Specifies who owns this card pile.
	 * PLAYER: a single player of the game
	 * COMMON: all players of the game
	 */
	public static enum Owner { PLAYER, COMMON }
	
	/**
	 * Specifies who can view this card pile.
	 * ALL: anyone
	 * OWNER: only the owner 
	 * OTHER: anyone but the owner
	 * NONE: no one
	 */
	public static enum Visibility { ALL, OWNER, OTHER, NONE }
	
	/**
	 * Specifies the number of face up cards on top of the pile.
	 * NUMBER: a number is specified [0, n]
	 * NONE: no cards are visible
	 * ALL: all cards are visible
	 * TOP: just the top card is face up
	 */
	public static enum Visible { NUMBER, NONE, ALL, TOP }
	
	/**
	 * Specifies how the pile should be arranged.
	 * STACKED: all cards in a single stack
	 * SPREAD: cards slightly spread out
	 * SPACED: cards do not touch one another
	 * MESSY: cards are in a messy pile
	 */
	public static enum Placement { STACKED, SPREAD, SPACED, MESSY }
	
	/**
	 * Specifies how the piles are oriented on the table.
	 * LANDSCAPE: Cards are placed sideways
	 * PORTRAIT: Cards are placed upright
	 */
	public static enum Orientation { LANDSCAPE, PORTRAIT }
	
	/**
	 * Specifies how the cards are placed with respect to the owner.
	 * HORIZONTAL: cards are placed from left to right
	 * VERTICAL: cards are placed from bottom to top
	 */
	public static enum Tiling { HORIZONTAL, VERTICAL }
	
	/**
	 * Specifies how card(s) are removed(played) from the pile.
	 * TOP: Top card removed first
	 * BOTTOM: Bottom card removed first
	 * RANDOM: a random card is removed
	 * ANY: Any card (user selected) is removed
	 * NONE: Cards are never removed from this pile
	 * ALL: All cards are removed at once
	 */
	public static enum Removal {TOP, BOTTOM, RANDOM, ANY, NONE, ALL}
	
/*------------------------------------------------
 	Constants and Attributes
 ------------------------------------------------*/	
	
	private final Deck deck;
	private final String name;
	private final Owner owner;
	private final Visibility visibility;
	private final Visible visible;
	private final Placement placement;
	private final Orientation orientation;
	private final Tiling tiling;
	private final Removal removal;
	private int numVisible;
	private List<PlayingCard> cards;
	private Random rand;					// Random number for shuffling
	
/*------------------------------------------------
 	Constructor(s)
 ------------------------------------------------*/

	/**
	 * Construct an empty <tt>CardPile</tt>.
	 * 
	 * @param pile	a file copy containing information about this card pile
	 * @param deck	reference to the deck of cards
	 * @throws FileParameterException	missing keywords or invalid parameters
	 */
	protected CardPile(final FileCopy pile, final Deck deck) throws FileParameterException {
		this.deck = deck;
		String keyword = "name";

		name = FileCopy.convertName(pile.getMandatoryParams(keyword));
		
		// Temporary attributes for the try/catch block
		Owner tempOwner = null;
		Visibility tempVisibility = null;
		Visible tempVisible = Visible.NUMBER;
		Placement tempPlacement = null;
		Orientation tempOrientation = null;
		Tiling tempTiling = null;
		Removal tempRemoval = null;
		
		// Try to read all of the card pile attributes from the file copy
		// The exception to catch could come from Enum.valueOf()...
		// The CardPile.getMandatoryParams can throw a FileParameterException,
		//	and this is handled upstream
		try {
			tempOwner = Owner.valueOf(pile.getMandatoryParams("owner").toUpperCase());
			tempVisibility = Visibility.valueOf(pile.getMandatoryParams("visibility").toUpperCase());
			tempPlacement = Placement.valueOf(pile.getMandatoryParams("placement").toUpperCase());
			tempOrientation = Orientation.valueOf(pile.getMandatoryParams("orientation").toUpperCase());
			tempTiling = Tiling.valueOf(pile.getMandatoryParams("tiling").toUpperCase());
			tempRemoval = Removal.valueOf(pile.getMandatoryParams("removal").toUpperCase());
			
			// A bit of extra care for the "Visible" Keyword (can be a number or word)
			String visibleParam = pile.getMandatoryParams("visible").toUpperCase();
			for (Visible val : Visible.values()) {
				if (val.name().equals(visibleParam)) {
					tempVisible = Visible.valueOf(visibleParam);
					break;
				}
			}
			numVisible = 0;
			if (tempVisible == Visible.NUMBER) {
				try {
					numVisible = Math.abs(Integer.valueOf(visibleParam));
				} catch (NumberFormatException e) {
					throw new IllegalArgumentException("No enum constant games.engine.util.CardPile.Visible." + visibleParam, e);
				}
			}

		// Exception thrown when a parameter is not a member of the appropriate Enumeration
		} catch (IllegalArgumentException e) {
			String[] message = e.getMessage().split("\\.");
			StringBuilder str = new StringBuilder();
			str.append("Invalid parameter \"");
			str.append(message[message.length-1]);
			str.append("\" for keyword \"");
			str.append(message[message.length-2]);
			str.append("\" in card pile: ");
			str.append(this.name);
			throw new FileParameterException(str.toString(), e);
		}

		owner = tempOwner;
		visibility = tempVisibility;
		visible = tempVisible;
		placement = tempPlacement;
		orientation = tempOrientation;
		tiling = tempTiling;
		removal = tempRemoval;
		cards = Collections.synchronizedList(new LinkedList<PlayingCard>());
	}
	
/*------------------------------------------------
    Accessors
 ------------------------------------------------*/
	
	/**
	 * Returns the name of this <tt>CardPile</tt>.
	 * 
	 * @return the name of this CardPile
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Returns the current size of this <tt>CardPile</tt>.
	 * 
	 * @return the current size of this CardPile
	 */
	public int getSize() {
		return cards.size();
	}
	
	/**
	 * Returns the <tt>Owner</tt> of this <tt>CardPile</tt>.
	 * 
	 * @return the Owner of this CardPile
	 */
	public Owner getOwner() {
		return owner;
	}
	
	/**
	 * Returns the <tt>Visibility</tt> of this <tt>CardPile</tt>.
	 * 
	 * @return the Visibility of this CardPile
	 */
	public Visibility getVisibility() {
		return visibility;
	}
	
	/**
	 * Returns the <tt>Visible</tt> of this <tt>CardPile</tt>.
	 * 
	 * @return the Visible of this CardPile
	 */
	public Visible getVisible() {
		return visible;
	}
	
	/**
	 * Returns the number of visible Cards in this <tt>CardPile</tt>.
	 * 
	 * @return the number of visible Cards in this CardPile
	 */
	public int getNumVisible() {
		return numVisible;
	}
	
	/**
	 * Returns the <tt>Placement</tt> of this <tt>CardPile</tt>.
	 * 
	 * @return the Placement of this CardPile
	 */
	public Placement getPlacement() {
		return placement;
	}
	
	/**
	 * Returns the <tt>Orientation</tt> of this <tt>CardPile</tt>.
	 * 
	 * @return the Orientation of this CardPile
	 */
	public Orientation getOrientation() {
		return orientation;
	}
	
	/**
	 * Returns the <tt>Tiling</tt> of this <tt>CardPile</tt>.
	 * 
	 * @return the Tiling of this CardPile
	 */
	public Tiling getTiling() {
		return tiling;
	}
	
	/**
	 * Returns the <tt>Removal</tt> of this <tt>CardPile</tt>.
	 * 
	 * @return the Removal of this CardPile
	 */
	public Removal getRemoval() {
		return removal;
	}
	
/*------------------------------------------------
    Card Utilities
 ------------------------------------------------*/
	/**
	 * Add the <tt>PlayingCard</tt> to this <tt>CardPile</tt>.
	 * 
	 * @param card	the playing card to be added
	 */
	public void add(final PlayingCard card) {
		cards.add(card);
	}
	
	/**
	 * Add the array of <tt>PlayingCards</tt> to this <tt>CardPile</tt>.
	 * It is undefined behavior to use this card pile as the specified array.
	 * 
	 * @param cards	the playing cards to be added
	 */
	public void add(final PlayingCard[] cards) {
		for (PlayingCard card : cards){
			this.cards.add(card);
		}
	}
	
	/**
	 * Add the collection of <tt>PlayingCards</tt> to this <tt>CardPile</tt>.
	 * It is undefined behavior to use this card pile as the specified collection.
	 * 
	 * @param cards	the playing cards to be added
	 * @throws NullPointerException - if the specified collection is null
	 */
	public void add(final Collection<PlayingCard> cards) throws NullPointerException {
		this.cards.addAll(cards);
	}
	
	/**
	 * Returns <tt>true</tt> if the specified <tt>PlayingCard</tt> is in this <tt>CardPile</tt>.
	 * 
	 * @param card the playing card to be located
	 * @return true is the specified card is found in this pile
	 */
	public boolean contains(PlayingCard card) {
		return this.cards.contains(card);
	}
	
	/**
	 * Returns <tt>true</tt> if this <tt>CardPile</tt> contains a card with the specified value.
	 * 
	 * @param value	the value of the playing card to be searched for
	 * @return true if this pile contains a card with the specified value
	 */
	public boolean contains(int value) {
		for (PlayingCard c : cards) {
			if (c.getValue() == value) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Removes the specified <tt>PlayingCard</tt> from this <tt>CardPile</tt>.
	 * Returns <tt>false</tt> if the specified card is not found.
	 * 
	 * @param card the playing card to be located
	 * @return false if the specified card is not found
	 */
	public boolean remove(PlayingCard card) {
		return ((LinkedList<PlayingCard>)cards).removeFirstOccurrence(card);
	}
	
	/**
	 * Removes and returns the first <tt>PlayingCard</tt> with the specified value from this <tt>CardPile</tt>.
	 * Returns <tt>null</tt> if no such card is found.
	 * 
	 * @param value	the value of the playing card to be searched for
	 * @return a PlayingCard with that value or null
	 */
	public PlayingCard remove(int value) {
		for (PlayingCard c : cards) {
			if (c.getValue() == value) {
				return c;
			}
		}
		return null;
	}
	
	/**
	 * Returns the top <tt>PlayingCard</tt> from this <tt>CardPile</tt>.
	 * The top card is that last one that was added.
	 * 
	 * @return the top PlayingCard from this CardPile
	 * @throws NoSuchElementException - if this card pile is empty
	 */
	public PlayingCard getTop() throws NoSuchElementException {
		return ((LinkedList<PlayingCard>) cards).getLast();
	}
	
	/**
	 * Removes and returns the top <tt>PlayingCard</tt> from this <tt>CardPile</tt>.
	 * The top card is that last one that was added.
	 * 
	 * @return the top PlayingCard from this CardPile
	 * @throws NoSuchElementException - if this card pile is empty
	 */
	public PlayingCard removeTop() throws NoSuchElementException {
		return ((LinkedList<PlayingCard>) cards).removeLast();
	}
	
	/**
	 * Returns the top <tt>PlayingCard</tt> from this <tt>CardPile</tt>.
	 * The top card is that last one that was added.
	 * 
	 * @return the top PlayingCard from this CardPile
	 * @throws NoSuchElementException - if this card pile is empty
	 */
	public PlayingCard getBottom() throws NoSuchElementException {
		return ((LinkedList<PlayingCard>) cards).getFirst();
	}
	
	/**
	 * Removes and returns the top <tt>PlayingCard</tt> from this <tt>CardPile</tt>.
	 * The top card is that last one that was added.
	 * 
	 * @return the top PlayingCard from this CardPile
	 * @throws NoSuchElementException - if this card pile is empty
	 */
	public PlayingCard removeBottom() throws NoSuchElementException {
		return ((LinkedList<PlayingCard>) cards).removeFirst();
	}
	
	/**
	 * Returns all of the <tt>PlayingCards</tt> from this <tt>CardPile</tt>.
	 * 
	 * @return all of the PlayingCards from this CardPile
	 */
	public PlayingCard[] getAll() {
		return (PlayingCard[]) cards.toArray();
	}
	
	/**
	 * Removes and returns all of the <tt>PlayingCards</tt> from this <tt>CardPile</tt>.
	 * 
	 * @return all of the PlayingCards from this CardPile
	 */
	public PlayingCard[] removeAll() {
		PlayingCard[] temp = (PlayingCard[]) cards.toArray();
		cards.clear();
		return temp;
	}
	
	/**
	 * Shuffle the cards in this <tt>CardPile</tt>.
	 */
	public void shuffle() {
		int ndx = 0;
		PlayingCard card = null;
		rand = ThreadLocalRandom.current();
		// Durstenfeld updated Fisher-Yates shuffle
		for (int i = cards.size() - 1; i > 0; i--) {
			ndx = rand.nextInt(i + 1);
			card = cards.get(ndx);
			cards.set(ndx, cards.get(i));
			cards.set(i, card);
		}
	}
	
	/**
	 * Sort this <tt>CardPile</tt> by increasing value of the Cards, if applicable.
	 */
	public void sortByIncreasingValue() {
		this.sortByValue(true);
	}
	
	/**
	 * Sort this <tt>CardPile</tt> by decreasing value of the Cards, if applicable.
	 */
	public void sortByDecreasingValue() {
		this.sortByValue(false);
	}
	
	/*
	 * 
	 */
	private void sortByValue(final boolean direction) {
		if (!deck.isRankingSpecified()) {
			this.sortByFace();
		}
		// TODO
	}
	
	/**
	 * Sort this <tt>CardPile</tt> by faces (put like faces together).
	 */
	public void sortByFace() {
		// TODO
	}
	
	/**
	 * Sort this <tt>CardPile</tt> by group (put like groups together), if applicable.
	 */
	public void sortByGroup() {
		if (!deck.isGroupingSpecified()) {
			this.sortByFace();
		}
		// TODO
	}
	
/*------------------------------------------------
    Overridden Methods
 ------------------------------------------------*/	

	/**
	 * Return information about this <tt>CardPile</tt>.
	 * 
	 * @return information about this CardPile
	 */
	@Override  public String toString() {
		StringBuilder str = new StringBuilder();
		String NEW_LINE = System.getProperty("line.separator");
		str.append("CardPile: ");
		str.append(name);
		str.append(NEW_LINE);
		str.append("Owner: ");
		str.append(owner);
		str.append(NEW_LINE);
		str.append("Visibility: ");
		str.append(visibility);
		str.append(NEW_LINE);
		str.append("Visible: ");
		str.append(visible);
		str.append(" (");
		str.append(numVisible);
		str.append(")"); 
		str.append(NEW_LINE);
		str.append("Placement: ");
		str.append(placement);
		str.append(NEW_LINE);
		str.append("Orientation: ");
		str.append(orientation);
		str.append(NEW_LINE);
		str.append("Tiling: ");
		str.append(tiling);
		str.append(NEW_LINE);
		str.append("Removal: ");
		str.append(removal);
		str.append(NEW_LINE);
		str.append("Top Card: ");
		str.append(cards.size() == 0 ? "NONE" : ((LinkedList<PlayingCard>) cards).getLast().toString());
		return str.toString();
	}
	
	
/*------------------------------------------------
    Main Method for Testing
 ------------------------------------------------*/	
	
	
	public static void main(String[] args) {
		System.out.println(" --- CardPile Test Bench ---");
		
		List<String> list = new ArrayList<String>(8);
		list.add("name test");
		list.add("owner player");
		list.add("visibility owner");
		list.add("visible all");
		list.add("placement spread");
		list.add("orientation portrait");
		list.add("tiling horizontal");
		list.add("removal any");
		
		FileCopy copy = null;
		try {
			copy = new FileCopy(list, "Test Card Pile");
		} catch (FileParameterException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		
		CardPile cardPile = null;
		
		try {
			
			cardPile = new CardPile(copy, null);
		} catch (FileParameterException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		System.out.println(cardPile.toString());

	}

}

