/***********************************************************************//**
* @file			FileParameterException.java
* @author		Kurt E. Clothier
* @date			November 7, 2015
*
* @breif		Special exception for plugin text files
*
* @pre			Compiler: Eclipse - Mars Release (4.5.0)
* @pre			Java: JRE 7 or greater
*
* @see			http://www.projectsbykec.com/
* @see			PlayingCard
*
* @copyright	The MIT License (MIT) - see LICENSE.txt
****************************************************************************/

package games.engine.util;

/************************************************************************
 * The FileParameterException Class
 * - Custom exception to consolidate issues involving plugin text files
 * - Composed exceptions should contain a message detailing the cause
 * Causes (not limited to): 
 * - IO issues (missing or corrupted files, etc)
 * - Missing mandatory keywords
 * - Invalid or missing keyword parameters
 * - Conflicts between keyword parameters 
 ************************************************************************/
public class FileParameterException extends Exception {

	private static final long serialVersionUID = -6051854619759670499L;

	/**
	 * Constructs a new <tt>FileParameterException</tt>.
	 */
	public FileParameterException() {
		this("File, keyword, or parameter error...");
	}
	
	/**
	 * Constructs a new <tt>FileParameterException</tt>.
	 * 
	 * @param message	information about this exception
	 */
	public FileParameterException(String message) {
		super(message);
	}
	
	/**
	 * Constructs a new <tt>FileParameterException</tt>.
	 * 
	 * @param cause	the original exception which caused this exception to be created
	 */
	public FileParameterException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * Constructs a new <tt>FileParameterException</tt>.
	 * 
	 * @param message	information about this exception
	 * @param cause		the original exception which caused this exception to be created
	 */
	public FileParameterException(String message, Throwable cause) {
		super(message, cause);
	}
	
	/**
	 * Constructs a new <tt>FileParameterException</tt>.
	 * 
	 * @param message	information about this exception
	 * @param cause		the original exception which caused this exception to be created
	 * @param enableSuppression		whether or not suppression is enabled
	 * @param writableStackTrace	whether or not the stack trace should be writable
	 */
	public FileParameterException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
