package games.engine.util;

public class CardGameTB {
	
	public static void main(String[] args) {


	}
}
