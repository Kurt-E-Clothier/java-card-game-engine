/***********************************************************************//**
* @file			CardPlayer.java
* @author		Kurt E. Clothier
* @date			November 5, 2015
*
* @breif		Player in a card game
*
* @pre			Compiler: Eclipse - Mars Release (4.5.0)
* @pre			Java: JRE 7 or greater
*
* @see			http://www.projectsbykec.com/
* @see			PlayingCard
*
* @copyright	The MIT License (MIT) - see LICENSE.txt
****************************************************************************/

package games.engine.util;

import java.util.HashMap;
import java.util.Map;

/************************************************************************
 * The CardPlayer Class
 * - This class represents a player in a card game.
 * 
 * TODO
 * - bridge card game to card pile objects
 * - methods for actions
 ************************************************************************/
public class CardPlayer extends AbstractPlayer{
	
/*------------------------------------------------
 	Constants and Attributes
 ------------------------------------------------*/
	private Map<String, CardPile> piles;	// Card Piles owned by this player

/*------------------------------------------------
 	Constructor(s)
 ------------------------------------------------*/
	
	/**
	 * Constructs a new <tt>CardPlayer</tt> with the given name.
	 * 
	 * @param name 		what to call this card player
	 * @param numPiles	how many card piles owned by this player
	 */
	protected CardPlayer(String name, int numPiles) {
		super(name);
		piles = new HashMap<String, CardPile>((int)(numPiles/0.75 +1));
	}
	
/*------------------------------------------------
    Accessors and Mutators
 ------------------------------------------------*/
	
	/**
	 * Returns the <tt>CardPile</tt> with the specified name.
	 * 
	 * @param name the <tt>CardPile</tt> to return
	 * @return the <tt>CardPile</tt> with the specified name
	 */
	public CardPile getPile(String name) {
		return piles.get(name);
	}
	
	/**
	 * Gives the created <tt>CardPile</tt> to this player.
	 * 
	 * @param pile CardPile to give to this player
	 */
	public void addPile(CardPile pile) {
		piles.put(pile.getName(), pile);
	}
	
	public void addCard() {
		
	}
	
	// create cardpiles
	
	// add cards to card piles
	
	// ???


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
